#!/bin/sh
docker build -t graalvm-native-image .