# Build the module

You can build the module simply by using this command -  
`mvn clean install`

Once the build succeeds, run -  
`mvn spring-boot:run`  

This will start the Spring Boot server at port `8080`.    

The startup will be approximately `1500 ms`, and the memory consumption should be around `200 MB`
