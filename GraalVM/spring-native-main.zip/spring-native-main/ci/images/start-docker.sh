#!/usr/bin/env bash

source /bin/docker-lib.sh
start_docker
