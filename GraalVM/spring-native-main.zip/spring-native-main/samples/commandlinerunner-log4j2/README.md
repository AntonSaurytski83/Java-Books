Very basic Spring Boot project using a `CommandLineRunner` bean with Log4j2.
