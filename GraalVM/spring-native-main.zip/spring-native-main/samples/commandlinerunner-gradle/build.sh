#!/usr/bin/env bash

 ${PWD%/*samples/*}/scripts/compileWithGradle.sh $* &&  ${PWD%/*samples/*}/scripts/test.sh $*