package com.example.javamail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavamailApplicationTests {

	@Test
	void contextLoads() {
	}

}
