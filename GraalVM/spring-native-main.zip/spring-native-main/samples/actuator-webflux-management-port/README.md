Spring Boot project with Spring WebFlux and Spring Boot actuators running on a separate port.
