Very basic Spring Boot project using a `CommandLineRunner` bean.
