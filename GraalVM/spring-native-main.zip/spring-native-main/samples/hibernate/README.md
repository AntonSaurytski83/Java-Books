Adaptation of Dave Syer app from https://github.com/scratches/vanilla-apps/tree/master/vanilla-orm
