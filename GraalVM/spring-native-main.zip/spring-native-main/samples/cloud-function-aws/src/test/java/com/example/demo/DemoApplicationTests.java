package com.example.demo;

//@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, properties = {"spring.main.web-application-type=servlet"})
//@ContextConfiguration(classes = {AWSCustomRuntime.class, DemoApplication.class})
//@TestPropertySource(properties = {"_HANDLER=foobar"})
public class DemoApplicationTests {

//	@Autowired
//	private AWSCustomRuntime aws;
//
//	@Test
//	public void test() {
//		assertThat(aws.exchange("\"oleg\"").getPayload()).isEqualTo("\"hi oleg!\"");
//		assertThat(aws.exchange("\"dave\"").getPayload()).isEqualTo("\"hi dave!\"");
//	}
}
