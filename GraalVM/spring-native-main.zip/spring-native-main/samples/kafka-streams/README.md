Spring Boot project with basic Apache Kafka Streams.
