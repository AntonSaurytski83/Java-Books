Spring Boot project with Spring MVC and Spring Boot actuators.
