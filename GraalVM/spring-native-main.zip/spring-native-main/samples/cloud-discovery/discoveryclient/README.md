# discoveryclient

Discovery client sample project.
