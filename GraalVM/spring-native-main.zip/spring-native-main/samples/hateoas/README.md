Spring Boot project with Spring HATEOAS.

Original Example taken from [spring-projects/spring-hateoas-examples](https://github.com/spring-projects/spring-hateoas-examples/tree/main/hypermedia).
