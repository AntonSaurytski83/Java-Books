**Warning: this sample is provided only for experimentation, Spring Batch is not supported for now.**

Very basic Spring Boot project running a Spring Batch job.

To build and run the native application packaged in a lightweight container:
```
mvn spring-boot:build-image
docker-compose up
```
