package com.example.batch;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BatchApplicationTests {

	@Test
	public void contextLoads() {
	}

}
