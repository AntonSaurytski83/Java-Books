Spring Boot project with Spring Integration.
