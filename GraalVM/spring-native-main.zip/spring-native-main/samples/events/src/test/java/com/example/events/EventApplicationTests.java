package com.example.events;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class EventApplicationTests {

	@Test
	public void contextLoads() {
	}

}
