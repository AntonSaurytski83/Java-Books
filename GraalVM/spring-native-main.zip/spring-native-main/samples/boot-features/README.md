Sample where we can add boot features over time.

It includes:
- @ConstructorBinding

To build and run the native application packaged in a lightweight container:
```
mvn spring-boot:build-image
docker-compose up
```
