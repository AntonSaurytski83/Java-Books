package com.example.bootfeatures;

public enum Color {
    red,green,blue;
}
