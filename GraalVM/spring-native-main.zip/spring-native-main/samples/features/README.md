This project is exercising Spring Features from the application point of view (the other
samples typically exercise them via picking up dependencies containing them).
