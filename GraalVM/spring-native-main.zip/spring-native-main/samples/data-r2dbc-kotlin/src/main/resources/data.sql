INSERT INTO reservation(name) VALUES ('Andy');
INSERT INTO reservation(name) VALUES ('Sebastien');