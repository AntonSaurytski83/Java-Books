Spring Boot project with Reactive Spring Data MongoDB.
