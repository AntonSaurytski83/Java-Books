Spring Boot project with Apache Kafka and Confluent Avro Serialization, and Avro schema-registry client.
