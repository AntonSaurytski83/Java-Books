Spring Boot project with Spring Webflux, Netty and R2DBC.
