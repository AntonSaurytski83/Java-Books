Spring Boot project with Spring Data Redis.
