package com.example.task;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class TaskApplicationTests {

	@Test
	public void contextLoads() {
	}

}
