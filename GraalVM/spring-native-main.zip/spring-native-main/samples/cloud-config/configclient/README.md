# configclient

This config client is using the new Boot 2.4 configuration loading scheme

```
spring.config.import=configserver:http://localhost:8888
```

