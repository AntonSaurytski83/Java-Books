Spring Boot project with Spring Data REST.
