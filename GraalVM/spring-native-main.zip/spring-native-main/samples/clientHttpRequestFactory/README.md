Testing ClientHttpRequestFactory

See https://github.com/spring-projects-experimental/spring-native/issues/1636
