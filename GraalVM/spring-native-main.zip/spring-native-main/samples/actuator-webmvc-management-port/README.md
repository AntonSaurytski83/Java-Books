Spring Boot project with Spring MVC and Spring Boot actuators running on a separate port.
