Spring Boot project with Spring WebFlux and Spring Boot actuators.
