#!/usr/bin/env bash

./mvnw -ntp clean install
