<!--
Welcome to the spring-native issue tracker. If you think you found a bug, please take the time to provide a complete minimal sample (something that we can unzip or git clone, build, and deploy) that reproduces the problem.

If you have a question, [StackOverflow](https://stackoverflow.com/tags/spring-native) is the place to be. We prefer to use GitHub issues only for bugs and enhancements.
-->
